/*
 *Sistema de calculadora
 */
package aula_13;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Sistema de calculadora
        int n1, n2, opcao;
        float resultado = 0;
         Scanner ler = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat ("0.00");  
        System.out.print("Digite o primeiro número: ");
        n1 = ler.nextInt();
        System.out.print("Digite o segundo número: ");
        n2 = ler.nextInt();
        System.out.println("## Menu de opções ##");
        System.out.println("1 - Adição");
        System.out.println("2 - Subtração");
        System.out.println("3 - Multiplicação");
        System.out.println("4 - Divisão");
        System.out.print("Selecione uma das opções:");
        opcao = ler.nextInt();
        switch(opcao) {
        case 1:
        resultado = n1 + n2;
        break;
        case 2:
        resultado  = n1 - n2;
        break;
        case 3:
        resultado  = n1 * n2;
        break;
        case 4:
        resultado  = n1 / n2;
        break;
        default:
        System.out.println("###_Operação invalida_###");
           
        }
        System.out.println("O resultado final é: " + df.format(resultado));       
    }
    
    
}
