/*
 * Sistema para verificar a cor do time do inter 
 */
package aula_9;

import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_2 {
    public static void main(String[] args) {
    String nome, cor;
    Scanner ler = new Scanner(System.in);
    System.out.print("Digite seu nome: ");
    nome = ler.nextLine();
    System.out.print("Digite a cor do time de futebol do internacional:");    
    cor = ler.nextLine();
        if ("vermelho".equals(cor.toLowerCase())) {
        System.out.println("Parabéns "+ nome + "! A cor do time do Internacional é vermelho");
        
        } else {
        System.out.println("Você errou "+ nome + "! A cor do time do internacional não é "+ cor);
                
        }
    }
 
    
     
}
