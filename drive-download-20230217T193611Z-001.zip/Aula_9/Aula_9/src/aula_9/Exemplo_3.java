/*
 * Sistema da fruteira Senac tech
 */
package aula_9;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_3 {
public static void main(String[] args) {
int unidade;
double total;       
Scanner ler = new Scanner(System.in); 
DecimalFormat df = new DecimalFormat("0.00");
System.out.print("Digite a quantidade que você deseja comprar: ");
unidade = ler.nextInt();
    if (unidade < 11) {
    total = unidade * 0.50;
    } else {
    total = unidade * 0.40;   
    }
    System.out.println("Você comprou " + unidade + " maçãs é vai pagar o total de " + df.format(total) );
    } 
    
}