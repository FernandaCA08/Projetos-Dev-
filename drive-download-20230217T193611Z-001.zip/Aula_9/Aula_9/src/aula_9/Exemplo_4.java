/*
 * Sistema para verificar se o número é par ou impar
 */
package aula_9;

import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_4 {
    public static void main(String[] args) {
    int num;
    Scanner ler = new Scanner(System.in);
    System.out.print("Informe o número inteiro: ");
    num = ler.nextInt();
        if (num % 2 == 0) {
            System.out.println("O número " + num + " é par ");
            
        } else {
            System.out.println("O número " + num + " é impar ");
        }
    }
    
}
