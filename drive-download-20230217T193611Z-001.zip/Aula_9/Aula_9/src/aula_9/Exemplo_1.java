/*
 * Sistema inteligente para verificar a idade  
 */
package aula_9;

import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_1 {

    /**
     *      */
    public static void main(String[] args) {
    // Sistema para informar a habilitação    
    String nome; 
    int idade;        
    Scanner ler = new Scanner(System.in);
    System.out.print("Digite seu nome: ");
    nome = ler.nextLine();
    System.out.print("Digite sua idade: ");
    idade = ler.nextInt();
        if (idade >= 18) {
            System.out.println("Seu nome é: "+ nome);
            System.out.println("Você já pode tirar a sua habilitação.");
        } else {
            System.out.println("Seu nome é: "+ nome);
            System.out.println("Você não pode tirar a sua habilitação.");
            
        }
        
        System.out.println("Obrigadx por participar da nossa pesquisa!");    
    }
    
}
 