/*
 * Sistema para informar assunto 
 */
package aula_10;

import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_3 {
    public static void main(String[] args) {
    Scanner ler = new Scanner(System.in);
    String nome;
    int idade;
    System.out.print("Informe seu nome: ");
    nome = ler.nextLine();
    System.out.print("Informe sua idade: ");
    idade = ler.nextInt();
        if (idade >= 14) {
            System.out.println("Você tem: " + idade);
            System.out.println("Parabéns " + nome + "você já pode solicitar sua carteira de trabalho! ");
            
        } else {
            System.out.println("Infelizmente você " + nome + "não pode solicitar a carteira de trabalho! ");
        }
    }
    
    
}
