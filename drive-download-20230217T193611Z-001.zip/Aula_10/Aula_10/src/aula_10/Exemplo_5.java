/*
 * Sistema para informar o valor da pesquisa
 */
package aula_10;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_5 {
    public static void main(String[] args) {
    Scanner ler = new Scanner(System.in);
    DecimalFormat df = new DecimalFormat("0.00");
    String nome;
    double valor, total, soma, v1, v2, v3, v4, v5;
    System.out.print("Informe o nome do produto pesquisado: ");
    nome = ler.nextLine();
    System.out.print("Informe o 1º valor: ");
    v1 = ler.nextDouble();
    System.out.print("Informe o 2º valor: ");
    v2 = ler.nextDouble();
    System.out.print("Informe o 3º valor: ");
    v3 = ler.nextDouble();
    System.out.print("Informe o 4º valor: ");
    v4 = ler.nextDouble();
    System.out.print("Informe o 5º valor: ");
    v5 = ler.nextDouble();
    soma = (v1+v2+v3+v4+v5)/5;
    
        if (soma >=2.00) {
            System.out.println("O valor do produto pesquisado é: " + soma);
            System.out.println("O produto pesquisado " + nome + " está caro! ");
            
            
        } else {
            System.out.println("O valor do produto pesquisado é: " + soma);
            System.out.println("O produto pesquisado " + nome + " está barato! ");
        }
    }
    
}
