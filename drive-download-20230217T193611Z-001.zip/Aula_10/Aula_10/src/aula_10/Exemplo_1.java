/*
 * Sistema para informar uma mensagem
 */
package aula_10;

import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    String nome, linguagem;
    Scanner ler = new Scanner(System.in);
    System.out.print("Digite seu nome: ");
    nome = ler.nextLine();
    System.out.println("Digite a linguagem que você estuda: ");
    linguagem = ler.nextLine();
        
    if ("java".equals(linguagem.toLowerCase())) {
            System.out.println("A linguagem você" + nome + "estuda: " + linguagem);
        } else 
            System.out.println("Você" + nome + "não estuda java: " + linguagem);{
        }
    
     
    }
    
}
