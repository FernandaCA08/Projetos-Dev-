/*
 * Sistema para contabilizar as laranjas 
 */
package aula_10;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_4 {
    public static void main(String[] args) {
    Scanner ler = new Scanner(System.in); 
    DecimalFormat df = new DecimalFormat("0.00");
    int unidade;
    double total;
    System.out.print("Digite a quantidade de laranjas que você deseja comprar: ");
    unidade = ler.nextInt();
        if (unidade < 5) {
            total = unidade * 1.00;
            
           
      } else {
            total = unidade * 0.80;
        }
       System.out.println("Você comprou " + unidade + " laranjas é vai pagar o total de " + df.format(total) ); 
    }
    
}
