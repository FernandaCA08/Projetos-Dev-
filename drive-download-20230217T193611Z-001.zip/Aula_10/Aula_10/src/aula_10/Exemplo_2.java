/*
 * Sistema inteligente para notas escolares
 */
package aula_10;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_2 {
    public static void main(String[] args) {
    String nome, snome;
    double n1,n2,n3,n4,n5,soma,media;
    Scanner ler = new Scanner(System.in);
    DecimalFormat df = new DecimalFormat("0.00");
    System.out.print("Nome do alunx é: ");
    nome = ler.nextLine();
    System.out.print("O sobrenome do alunx é: ");
    snome = ler.nextLine();
    System.out.print("Qual a primeira nota: ");
    n1 = ler.nextDouble();
    System.out.print("Qual a segunda nota: ");
    n2 = ler.nextDouble();
    System.out.print("Qual a terceira nota: ");
    n3 = ler.nextDouble();
    System.out.print("Qual a quarta nota: ");
    n4 = ler.nextDouble();
    System.out.print("Qual a quinta nota: ");
    n5 = ler.nextDouble();
    soma = (n1+n2+n3+n4+n5)/5;
    
    System.out.println("O nome do Alunx é: "+nome);
    System.out.println("o sobrenome é: "+snome);
    System.out.println("A nota 1 é: "+n1);
    System.out.println("A nota 2 é: "+n2);
    System.out.println("A nota 3 é: "+n3);
    System.out.println("A nota 4 é: "+n4);
    System.out.println("A nota 5 é: "+n5);
    System.out.println("A media final das notas é: "+soma);
      
    if (soma >= 7) {
        
        System.out.println("Parabéns você foi aprovadx: " + nome);
        System.out.println("Sua nota ficou em: " + soma);    
        } else {
        System.out.println("Infelizmente você ficou recuperação: " + nome);
        
        }
    
    }
    
}
