/*
 * 
 */
package aula_12;

import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_4 {
    public static void main(String[] args) {
    String nome;
    Scanner ler = new Scanner(System.in);
    System.out.println("você prefere qual biscoito, Atenados, Cartoon, Oreo ou Bono?: ");
    System.out.print("Digite o nome do seu biscoito favorito: ");
    nome = ler.nextLine();
    if (("ATENADOS" .equals(nome.toUpperCase())) || ("CARTOON" .equals(nome.toUpperCase()))) {
        System.out.println("Você tem preferência aos biscoitos mais em conta!");       
    } else {
     if (("OREO" .equals(nome.toUpperCase())) || ("BONO" .equals(nome.toUpperCase()))) {
        System.out.println("Você tem preferência aos biscoitos mais caros!");       
    } else {  
         System.out.println("O biscoito digitado não está na lista!");
     }  
        }
    }
    
}
