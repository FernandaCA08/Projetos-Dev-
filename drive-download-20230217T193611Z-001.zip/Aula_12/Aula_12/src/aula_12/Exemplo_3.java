/*
 * Sistema para calcular as 4 operações
 */
package aula_12;

import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_3 {
    public static void main(String[] args) {
    double v1, v2, resultado;
    String operacao;       
    Scanner ler = new Scanner(System.in);
    System.out.print("Digite o primeiro valor: ");
    v1 = ler.nextDouble();
    ler.skip("\\R");
    System.out.print("Mostre a operação desejada: ");
    operacao = ler.nextLine();
    System.out.print("Digite o segundo valor: ");
    v2 = ler.nextDouble();
    System.out.println("O primeiro valor é: "+ v1);
    System.out.println("A operação escolhida é: "+ operacao);
    System.out.println("O segundo valor é: "+ v2);
    if ("+" .equals(operacao)) {
    resultado = v1 + v2; 
    System.out.println("O resultado da operação é: "+ resultado);
        } else {
    if ("-" .equals(operacao)) {
    resultado = v1 - v2; 
    System.out.println("O resultado da operação é: "+ resultado);
        } else {
    if ("*" .equals(operacao)) {
    resultado = v1 * v2;
    System.out.println("O resultado da operação é: "+ resultado);
        } else {
    if ("/" .equals(operacao) ) {
    resultado = v1 / v2;
    System.out.println("O resultado da operação é: "+ resultado);
        } else {
        }
    
        }
    
        }
        }
    }
    
}
