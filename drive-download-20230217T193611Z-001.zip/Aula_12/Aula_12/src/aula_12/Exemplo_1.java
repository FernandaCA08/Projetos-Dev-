/*
 *Sistema para corretor
 */
package aula_12;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Sistema para calcular comissão
        Scanner ler = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat ("0.00");
        String nome;
        double comissao = 0, valor, total;
        System.out.print("Nome do corretor:");
        nome = ler.nextLine();
        System.out.print("Valor do imóvel:");
        valor = ler.nextDouble();
        total = comissao + valor;
        System.out.println("O nome do corretor é: "+ nome);
        System.out.println("O valor total da venda é: "+ df.format(total));
        if (valor >= 50000) {
        comissao = valor * 0.20;
        System.out.println("A comissão da venda é: "+ df.format(comissao));   
        } else {
        if (valor >= 30000 ) {
        comissao = valor * 0.15;    
        System.out.println("A comissão da venda é: "+ df.format(comissao));       
            } else {
        if (valor < 30000) {
        comissao = valor * 0.10;
        System.out.println("A comissão da venda é: "+ df.format(comissao)); 
            } else {
            }
     
            }
    
        }
    }
    
}
