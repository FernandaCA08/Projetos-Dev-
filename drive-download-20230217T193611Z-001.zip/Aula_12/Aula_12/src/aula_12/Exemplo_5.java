/*
 * Sitema para informar os descontos
 */
package aula_12;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author 182100356
 */
public class Exemplo_5 {
    public static void main(String[] args) {
     Scanner ler = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat ("0.00");  
        double valor, total = 0, desconto;
        System.out.print("Digite o valor da compra: ");
        valor = ler.nextDouble();
        System.out.println("O valor original do produto é: "+ valor);  
        if ((valor >=0) && (valor <=200)) {
        desconto = valor * 0.05;
        total = valor - desconto;
            System.out.println("Você recebeu um desconto de 5%: " + df.format(total));
        } else {
        if (valor >200 && valor <=400) {
        desconto = valor * 0.08;
        total = valor - desconto;
            System.out.println("Você recebeu um desconto de 8%: " + df.format(total));    
        } else {
            if (valor >400) {
        desconto = valor * 0.10;
        total = valor - desconto;
            System.out.println("Você recebeu um desconto de 10%: " + df.format(total));       
            } else {
            }
            }
        }
    }
    
}
  