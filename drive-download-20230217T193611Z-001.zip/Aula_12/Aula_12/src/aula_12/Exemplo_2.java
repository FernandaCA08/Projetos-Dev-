/*
 * Sistema para produtos
 */
package aula_12;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author 182100356
 */
public class Exemplo_2 {
    public static void main(String[] args) {
    String  nome;
    double  valor = 0, total, opcao;      
    Scanner ler = new Scanner(System.in);
    DecimalFormat df = new DecimalFormat("0.00"); 
       System.out.print("Digite seu nome: ");
        nome = ler.nextLine();
        System.out.print("Digite o valor do produto: ");
        valor = ler.nextDouble();
        System.out.println("## Opções para forma de pagagamento ##");
        System.out.println("1 - Venda a vista - 10% desconto");
        System.out.println("2 - Venda a prazo 30 dias - 5% desconto");
        System.out.println("3 - Venda a prazo 60 dias - mesmo preço");
        System.out.println("4 - Venda a prazo 90 dias - 5% acréscimo");
        System.out.println("5 - Venda com cartão de débito- 8% desconto");
        System.out.print("Selecione uma das opções:");
        opcao = ler.nextDouble();
        total = valor + opcao;
        System.out.println("Seu nome é: "+ nome);
        System.out.println("A forma de pagamento é "+ opcao);
        System.out.println("O valor do produto é: "+ df.format(valor));
        if (opcao == 1) {
        total = valor - (valor * 0.10); 
        System.out.println("Você solicitou a opção 1 com desconto de 10% "+ df.format(total));
        } else {
        if (opcao == 2) {
         total = valor - (valor * 0.05); 
        System.out.println("Você solicitou a opção 2 com desconto de 5% "+ df.format(total));         
        } else {
        if (opcao == 3) {
        total = valor;
        System.out.println("Você solicitou a opção 3 e ira pagar o mesmo valor "+ df.format(total)); 
        } else {
        if (opcao == 4) {
        total = valor - (valor * 0.05); 
         System.out.println("Você solicitou a opção 4 com desconto de 5% "+ df.format(total));         
        } else {
        if (opcao == 5) {
        total = valor - (valor * 0.08); 
         System.out.println("Você solicitou a opção 5 com desconto de 8% "+ df.format(total));         
        } else {
            }
    
            }
            }
     
            }
    
        }
        
    }
 
   
    
}
