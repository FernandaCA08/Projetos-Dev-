/*
 * Programa para subtrair dois numeros inteiros 
 */
package aula_6;

import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_2 {
    
     public static void main(String[] args) {
     
         int n1,n2,subtracao;
         Scanner ler = new Scanner(System.in);
         System.out.print("Informe o primeiro número: ");
         n1 = ler.nextInt();
         System.out.print("Informe o segundo  número: ");
         n2 = ler.nextInt();
         subtracao = n1 - n2;
         System.out.println("A subtração dos números digitados é: "+subtracao);
         
   
    }
}
