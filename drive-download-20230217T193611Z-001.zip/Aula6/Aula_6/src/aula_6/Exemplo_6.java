/*
 * Programa para solicitar dados de um aluno 
 */
package aula_6;

import java.util.Scanner;

/**
 *
 * @author 182100356
 */
public class Exemplo_6 {
    
    public static void main(String[] args) {
        
        String nome;
        int turma;        
        double n1,n2,n3,n4,n5;
        double soma;
        Scanner ler = new Scanner(System.in);
        System.out.print("Nome do(a) Aluno(a): ");
        nome = ler.nextLine();
        System.out.print("A turma é: ");
        turma = ler.nextInt();
        System.out.print("Nota 1: ");
        n1 = ler.nextDouble();
        System.out.print("Nota 2: ");
        n2 = ler.nextDouble();
        System.out.print("Nota 3: ");
        n3 = ler.nextDouble();
        System.out.print("Nota 4: ");
        n4 = ler.nextDouble();
        System.out.print("Nota 5: ");
        n5 = ler.nextDouble();
        soma = (n1+n2+n3+n4+n5)/5;
        System.out.println("O nome do(a) Aluno(a) é: "+nome);
        System.out.println("A turma é: "+turma);
        System.out.println("A nota 1 é: "+n1);
        System.out.println("A nota 2 é: "+n2);
        System.out.println("A nota 3 é: "+n3);
        System.out.println("A nota 4 é: "+n4);
        System.out.println("A nota 5 é: "+n5);
        System.out.println("A media final das notas é: "+soma);        
    }
    
}
