/*
 * Programa para dividir dois numeros 
 */
package aula_6;

import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_4 {
    
    public static void main(String[] args) {
        
         Scanner ler = new Scanner(System.in);
         int n1,n2,divisao;
         System.out.print("Digite o primeiro número: ");
         n1 = ler.nextInt();
         System.out.print("Digite o segundo número: ");
         n2 = ler.nextInt();
         divisao = n1 / n2;
         System.out.println("A divisão dos números é: "+divisao);
    }
}
