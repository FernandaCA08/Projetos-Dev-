/*
 *Programa para somar dois numeros inteiros 
 * 
 */
package aula_6;

import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    int n1,n2,soma;
        Scanner ler = new Scanner(System.in);
        
        System.out.print("Informe o primeiro número: ");
        n1 = ler.nextInt();
        System.out.print("Informe o segundo  número: ");
        n2 = ler.nextInt();
        
        soma = n1 + n2;
        System.out.println("A soma dos números digitados é: "+soma);
        
                
    }
    
}
