/*
 * Programa para calcular a potencia 
 */
package aula_6;

import java.util.Scanner;

/**
 *
 * @author 182100356
 */
public class Exemplo_5 {
    
    public static void main(String[] args) {
        int n1,n2;
        double pot;
        Scanner ler = new Scanner(System.in);       
        System.out.print("Informe o número inteiro: ");
        n1 = ler.nextInt();
        System.out.print("Informe o segundo número inteiro: ");
        n2 = ler.nextInt();
        pot = Math.pow(n1, n2);
        System.out.println("A potencia dos números é: "+pot);
    }
}
