/*
 * Exercicio 2
 */
package exercicio_2;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exercicio_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Exercicio 2
    String nomedoproduto;
    double  custodoproduto, percentualdesconto, valor, venda;        
    Scanner ler = new Scanner(System.in);
    DecimalFormat df = new DecimalFormat("0.00");
     System.out.print("Nome do produto: ");
     nomedoproduto = ler.nextLine();
     System.out.print("Custo do prduto: ");
     custodoproduto = ler.nextDouble();
     System.out.print("Percentual do produto: ");
     percentualdesconto = ler.nextDouble();
     venda = custodoproduto - (custodoproduto* (percentualdesconto/100));
     System.out.println("Nome do produto: "+nomedoproduto);
     System.out.println("Valor da venda: "+venda);   
     System.out.println("Desconto do produto: % " + df.format(custodoproduto-venda));
     
    }
}
