/*
 * Sistema de pesquisa de valor 
 */
package exercicio_2;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exercicio_3 {
public static void main(String[] args) {
String nomedoproduto;
double media, soma, valor1, valor2, valor3, valor4, valor5, valor6, valor7;          
Scanner ler = new Scanner(System.in);
DecimalFormat df = new DecimalFormat("0.00");
System.out.print("Nome do produto pesquisado: ");
nomedoproduto = ler.nextLine();
System.out.print("1º valor pesquisado: ");
valor1 = ler.nextDouble();
System.out.print("2º valor pesquisado: ");
valor2 = ler.nextDouble();
System.out.print("3º valor pesquisado: ");
valor3 = ler.nextDouble();
System.out.print("4º valor pesquisado: ");
valor4 = ler.nextDouble();
System.out.print("5º valor pesquisado: ");
valor5 = ler.nextDouble();
System.out.print("6º valor pesquisado: ");
valor6 = ler.nextDouble();
System.out.print("7º valor pesquisado: ");
valor7 = ler.nextDouble();
media = (valor1 + valor2 + valor3 + valor4 + valor5 + valor6 + valor7) /7  ;
System.out.println("Nome do produto pesquisado é: "+nomedoproduto);
System.out.println("A media de valor do produto é: "+ df.format(media));
    }
    
}
