/*
 *  Sistema para imobiliária 
 */
package exercicio_2;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exercicio_4 {
    public static void main(String[] args) {
    String tipodeimovel;
    double valordoimovel, revendedor, imobiliaria, total;       
    Scanner ler = new Scanner(System.in);
    DecimalFormat df = new DecimalFormat("0.00");
    System.out.print("Tipo de imóvel: ");
    tipodeimovel = ler.nextLine();
    System.out.print("Valor do imóvel: R$");    
    valordoimovel = ler.nextDouble();
    revendedor = valordoimovel* 0.05;  
    imobiliaria = valordoimovel* 0.30;
    total = valordoimovel + revendedor + imobiliaria;
    System.out.println("O tipo de imóvel é: "+ tipodeimovel);
    System.out.println("O valor do imóvel é: "+ valordoimovel);
    System.out.println("O total do valor é: "+ df.format(total));
    
    
    
    }
}
