/*
 * Sitema de controle de percentual 
 */
package aula_8;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_3 {
    public static void main(String[] args) {
    String nomedoproduto1, nomedoproduto2;
    double valordoproduto1, valordoproduto2, acrescimo, venda;        
    Scanner ler = new Scanner(System.in);
    DecimalFormat df = new DecimalFormat("0.00");
        System.out.print("Nome do produto 1: ");
        nomedoproduto1 = ler.nextLine();
        System.out.print("Nome do prduto 2: ");
        nomedoproduto2 = ler.nextLine();
        System.out.print("Valor do produto 1: R$ ");
        valordoproduto1 = ler.nextDouble();
        System.out.print("Valor do produto 2: R$ ");
        valordoproduto2 = ler.nextDouble();
        System.out.print("Percentual de acrescimo: % ");
        acrescimo = ler.nextDouble();
        System.out.println("Nome do 1º produto e valor: " +nomedoproduto1 + valordoproduto1);
        System.out.println("Nome do 2º produto e valor: " +nomedoproduto2 + valordoproduto2);
        venda = valordoproduto1 +  (valordoproduto2* (acrescimo/100));
        System.out.println("O total de acrescimo dos produtos é: "+ df.format(venda));
    }
    
    
}
