/*
 * Sistema de controle de produtos 
 */
package aula_8;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Fernanda 
 */
public class Exemplo_2 {
    public static void main(String[] args) {
     String nomedoproduto;
     double custo, venda, acrescimo;
     Scanner ler = new Scanner(System.in);
     DecimalFormat df = new DecimalFormat("0.00"); 
        System.out.print("Nome do do produto: ");
        nomedoproduto = ler.nextLine();
        System.out.print("Custo do prduto: ");
        custo = ler.nextDouble();
        System.out.print("Percentual de acrescimo: %");
        acrescimo = ler.nextDouble();
        venda = custo + (custo*(acrescimo / 100));
        System.out.println("O produto deve ser vendido à: R$"+ df.format(venda));
        
  
    }
    
}
