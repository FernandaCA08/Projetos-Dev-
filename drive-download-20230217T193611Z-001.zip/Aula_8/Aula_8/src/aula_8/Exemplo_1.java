/*
 * Sistema para controle de prestações 
 */
package aula_8;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author 182100356
 */
public class Exemplo_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     //Sistema para controle de prestações 
     int tempo;
     double total, prestacao, juros, sub, taxa;             
     Scanner ler = new Scanner(System.in);
     DecimalFormat df = new DecimalFormat("0.00");
        System.out.print("Valor da prestação: R$ ");
        prestacao = ler.nextDouble();
        System.out.print("Quantos dias de atraso: ");
        tempo = ler.nextInt();
        System.out.print("Taxa de juros mensal: % ");
        taxa = ler.nextDouble();
        sub = (taxa / 30)/100;
        total = prestacao + (prestacao*sub*tempo);
        juros = total - prestacao;
        System.out.println("Total da taxa de juros a ser cobrado: R$ "+df.format(juros));
        System.out.println("Total da prestação: R$ "+df.format(total));
        
    }
    
}
