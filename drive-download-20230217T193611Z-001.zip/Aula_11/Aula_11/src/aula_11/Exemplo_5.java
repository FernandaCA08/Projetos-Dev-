/*
 *Sistema de preferencia de carro
 */
package aula_11;

import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_5 {
    public static void main(String[] args) {
    String nome;
    Scanner ler = new Scanner(System.in);
    System.out.println("Informe qual dos veiculos da lista que você acha mais bonito:"); 
    System.out.println("Fusca, Opala, Ferrari ou Porche:");
    nome = ler.nextLine();
        if (("FUSCA".equals(nome.toUpperCase())) || ("OPALA".equals(nome.toUpperCase()))) {
            System.out.println("Você acha os carros mais antigos bonitos!");
        } else {
        if (("FERRARI".equals(nome.toUpperCase())) || ("PORCHE".equals(nome.toUpperCase()))){
             System.out.println("Você acha os carros mais novos bonitos!");    
        } else {
            System.out.println("Você escolheu um carro que não está na lista!");
            }
        }
    }
   
}
