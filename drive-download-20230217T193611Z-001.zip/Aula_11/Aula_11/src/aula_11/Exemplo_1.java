/*
 * Sistema Escolar 
 */
package aula_11;

import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Sistema Escolar
        String nome;
        float n1,n2,n3,n4,n5,media;
        Scanner ler = new Scanner(System.in);
        System.out.print("Digite o nome do alunx:");
        nome = ler.nextLine();
        System.out.print("Digite a primeira nota:");
        n1 = ler.nextFloat();
        System.out.print("Digite a segunda nota:");
        n2 = ler.nextFloat();
        System.out.print("Digite a terceira nota:");
        n3 = ler.nextFloat();
        System.out.print("Digite a quarta nota:");
        n4 = ler.nextFloat();
        System.out.print("Digite a quinta nota:");
        n5 = ler.nextFloat();
        media = (n1+n2+n3+n4+n5)/5;
        System.out.println("O nome do aluno é: "+nome);
        if (media >= 7) {
            System.out.println("A media final das suas notas foi: "+ media + ",é você foi aprovado");
        } else {
            if (media >= 5) {
                System.out.println("A media final das suas notas foi: "+ media + ",é você está em recuperação");   
            } else {
            }  System.out.println("A media final das suas notas foi: "+ media + ",é você foi reprovado");
        }
        
    }
    
}
