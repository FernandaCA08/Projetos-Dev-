/*
 * 
 */
package aula_11;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Fernanda 
 */
public class Exemplo_4 {
    public static void main(String[] args) {
        String nome;
        float n1,n2,n3,n4,n5,media;
        Scanner ler = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("0.00");
        System.out.print("Digite o nome do alunx:");
        nome = ler.nextLine();
        System.out.print("Digite a primeira nota:");
        n1 = ler.nextFloat();
        System.out.print("Digite a segunda nota:");
        n2 = ler.nextFloat();
        System.out.print("Digite a terceira nota:");
        n3 = ler.nextFloat();
        System.out.print("Digite a quarta nota:");
        n4 = ler.nextFloat();
        System.out.print("Digite a quinta nota:");
        n5 = ler.nextFloat();
        media = (n1+n2+n3+n4+n5)/5;
        System.out.println("Nome do alunx é: "+ nome);
        if ((media >= 7) && (media <= 10)) {
        System.out.println("A media final do aluno foi:"+ df.format(media)+ ", é foi aprovado!");
        } else {
        if ((media >= 5) && (media < 7)) {
        System.out.println("A media final do aluno foi:"+ df.format(media)+ ", está em recuperação!");        
            } else {
        if ((media >= 0) && (media <5)) {
        System.out.println("A media final do aluno foi:"+ df.format(media)+ ", é foi reprovado!");        
            } else {
            System.out.println("Erro no sistema, tente novamente!");    
            }
            }
        }
        
    }
    
}
