/*
 * Sistema para uma sorveteria 
 */
package aula_11;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_3 {
    public static void main(String[] args) {
        int opcao, quantidade;
        double total = 0;
        Scanner ler = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("0.00");
        System.out.println("## Sorveteria da Feh ##");
        System.out.println("1 - Picole de Uva R$ 1,00");
        System.out.println("2 - Picole de Laranja R$ 1,25");
        System.out.println("3 - Picole de Milho R$ 1,50");
        System.out.print("Selecione uma das opções:");
        opcao = ler.nextInt();
        System.out.print("Digite a quantidade de picoles que deseja comprar:");
        quantidade = ler.nextInt();
        if (opcao == 1) {
           total = quantidade * 1.00; 
        } else {
        if (opcao == 2) {
            total = quantidade * 1.25;    
        } else {
        if (opcao == 3) {
            total = quantidade * 1.50;     
        } else {
            System.out.println("Opção invalida!");
            }
    
            }
        }
        System.out.println("A quantidade de picoles vendidos foi: "+ quantidade);
        System.out.println("O valor total da compra foi: "+ df.format(total));
        
        
    }
    
}
