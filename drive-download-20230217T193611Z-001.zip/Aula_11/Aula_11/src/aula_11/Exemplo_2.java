/*
 * Calculadora básica
 */
package aula_11;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_2 {
    public static void main(String[] args) {
    int n1, n2, opcao;
    double resultado = 0;
    Scanner ler = new Scanner(System.in);
    DecimalFormat df = new DecimalFormat("0.00");
    System.out.print("Diigite o primeiro número inteiro:");
    n1 = ler.nextInt();
    System.out.print("Digite o segundo número inteiro:");
    n2 = ler.nextInt();
    System.out.println("### MENU ###");
    System.out.println("1 - Adição");
    System.out.println("2 - Subtração");
    System.out.println("3 - Multiplicação");
    System.out.println("4 - Divisão");
    System.out.println("Selecione uma das opções");
    opcao = ler.nextInt();
        if (opcao == 1) {
            resultado = n1 + n2;
        } else {
        if (opcao == 2) {
            resultado = n1 - n2;          
        } else {
        if (opcao == 3) {
            resultado = n1 * n2;    
            } else {
        if (opcao == 4) {
            resultado = n1 / n2;    
            } else {
                System.out.println("Opção invalida!");
            }
    
            }
    
            }
        }
        System.out.println("O resultado final é:"+ df.format(resultado));
    }
    
}
