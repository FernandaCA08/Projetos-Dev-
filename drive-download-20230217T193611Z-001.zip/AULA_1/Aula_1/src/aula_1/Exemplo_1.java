/*
 * Meu primeiro projeto para o curso de aprendizagem
 *
 * 
 */
package aula_1;

/**
 *
 * @author Fernanda de Campos
 */
public class Exemplo_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // imprimir um texto na tela
        
        System.out.println("Olá mundo");
        System.out.println("Meu primeiro programa em Java");
         
        
        
        
        
        
        
        
        
        
        
        
        
        
        
              
    }
    
}
