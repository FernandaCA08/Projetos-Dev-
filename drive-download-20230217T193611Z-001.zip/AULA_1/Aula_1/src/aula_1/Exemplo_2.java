/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula_1;

/**
 *
 * @author 182100356
 */
public class Exemplo_2 {
    public static void main(String[] args) {
        System.out.println("Nome: Fernanda ");
        System.out.println("Idade: 21 ");
        System.out.println("Residência: Av.Cavalhada");
        System.out.println("Bairro: Cavalhada");
        System.out.println("Cidade: Poa");
        System.out.println("Estado: RS");
    }
    
    
}
