/*
 *Faça um programa que solicite o nome e sobrenome de uma pessoa 
ao final mostre os dados armazenados 
 * 
 */
package aula_1;

import java.util.Scanner;

/**
 *
 * @author Fernanda
 */
public class Exemplo_3 {
    public static void main(String[] args) {
        
        String nome, snome;

        Scanner ler = new Scanner(System.in); 
         
        System.out.println("Informe seu nome: ");
        nome = ler.nextLine();
        
        System.out.println("Informe seu sobrenome: ");
        snome = ler.nextLine();
        
        
        System.out.println("O seu nome é: "+nome);
        System.out.println("O seu sobrenome é:"+snome);
        System.out.println("Seu nome completo é: "+nome+" "+snome);
        
                
    }
    
}
