/*
*Faça um programa que solicite os dados de uma pessoa 
ao final mostre os dados armazenados  
*
 */
package aula_1;

import java.util.Scanner;

        

/**
 *
 * @author 182100356
 */
public class Exemplo_4 {
    public static void main(String[] args) {
        
        String nome,snome;
        int idade;
        long cpf,rg,numero;
        String endereço,bairro,cidade,estado;
        Scanner ler = new Scanner(System.in);
        System.out.println("Informe seu Nome: ");
        nome = ler.nextLine();
        System.out.println("Informe seu Sobrenome: ");
        snome = ler.nextLine();
        System.out.println("Informe sua Idade: ");
        idade = ler.nextInt();
        System.out.println("Informe seu CPF: ");
        cpf = ler.nextLong();
        System.out.println("Informe seu RG: ");
        rg = ler.nextLong();
        ler.skip("\\R");
        System.out.println("Informe seu Endereço: ");
        endereço = ler.nextLine();
        System.out.println("Informe seu Número: ");
        numero = ler.nextLong();
        ler.skip("\\R");
        System.out.println("Informe seu Bairro: ");
        bairro = ler.nextLine();
        System.out.println("Informe sua Cidade: ");
        cidade = ler.nextLine();
        System.out.println("Informe seu Estado: ");
        estado = ler.nextLine();
        System.out.println("Seu nome é: "+nome);
        System.out.println("Seu sobrenome é: "+snome);
        System.out.println("Sua idade é: "+idade);
        System.out.println("Seu CPF é: "+cpf);
        System.out.println("Seu RG é: "+rg);
        System.out.println("Seu Endereço é: "+endereço);
        System.out.println("Seu Número é: "+numero);
        System.out.println("Seu Bairro é: "+bairro);
        System.out.println("Sua Cidade é: "+cidade);
        System.out.println("Seu Estado é: "+estado);
    }
    
}
